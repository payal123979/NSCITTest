package com.nscit.assignments.test.entity;

public class UserPojo {
	
	private long id;
	private String name;
	private String email;
	private String password;
	private int[] arr;
	private int[] arr2;
	private String palindrome;
	
	
	
	
	public String getPalindrome() {
		return palindrome;
	}
	public void setPalindrome(String palindrome) {
		this.palindrome = palindrome;
	}
	public int[] getArr() {
		return arr;
	}
	public void setArr(int[] arr) {
		this.arr = arr;
	}
	public int[] getArr2() {
		return arr2;
	}
	public void setArr2(int[] arr2) {
		this.arr2 = arr2;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "UserPojo [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + "]";
	}
	
	

}
