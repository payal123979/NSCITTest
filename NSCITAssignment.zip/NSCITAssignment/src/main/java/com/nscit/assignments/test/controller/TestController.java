package com.nscit.assignments.test.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.UriComponentsBuilder;

import com.nscit.assignments.test.entity.UserPojo;

@Controller
public class TestController {
	
	PasswordHashing passwordHashing=new PasswordHashing();
	
	@RequestMapping(value="/")
	public ModelAndView index() {
		ModelAndView mav=new ModelAndView();
		mav.setViewName("index");
		return mav;
	}
	
	@RequestMapping("/signUp")
	public ModelAndView signUp() {
		ModelAndView mav=new ModelAndView();
		mav.addObject("userDetails",new UserPojo());
		mav.setViewName("signup");
		return mav;
	}
	
	@RequestMapping("/saveUserData")
	public ModelAndView saveUserData(@ModelAttribute("userDetails") UserPojo userPojo,UriComponentsBuilder builder) {
		System.out.println("data "+userPojo.getEmail());
		ModelAndView mav = new ModelAndView();
		RestTemplate restTemplate=new RestTemplate();
		userPojo.setPassword(passwordHashing.generateHash(userPojo.getPassword()));
		HttpHeaders headers = new HttpHeaders();
	      headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
	      headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<UserPojo> request = new HttpEntity<>(userPojo,headers);
		 
		ResponseEntity<UserPojo> response = restTemplate.exchange("http://localhost:8082/NSCIT-RestAPI/saveUserData", HttpMethod.POST, request, UserPojo.class);
		System.out.println("result "+response);
		if(response!=null) {
			mav.setViewName("index");
		}
		return mav;
	}
	
	@RequestMapping("/login")
	public ModelAndView login() {
		ModelAndView mav=new ModelAndView();
		mav.addObject("requestPojo",new UserPojo());
		mav.setViewName("login");
		return mav;
	}
	
	@RequestMapping("/saveLoginData")
	public ModelAndView saveLoginData(@ModelAttribute("requestPojo") UserPojo userPojo,UriComponentsBuilder builder,HttpServletRequest req,HttpServletResponse res) {
		System.out.println("data "+userPojo.getEmail());
		ModelAndView mav = new ModelAndView();
		RestTemplate restTemplate=new RestTemplate();
		UserPojo u = new UserPojo();
		u.setEmail(userPojo.getEmail());
		u.setPassword(passwordHashing.generateHash(userPojo.getPassword()));
		HttpHeaders headers = new HttpHeaders();
	      headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
	      headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<UserPojo> request = new HttpEntity<>(u,headers);
		 
		ResponseEntity<UserPojo> response = restTemplate.exchange("http://localhost:8082/NSCIT-RestAPI/saveLoginData", HttpMethod.POST, request, UserPojo.class);
		
		System.out.println("result "+response);
		HttpSession session = req.getSession();
		session.setAttribute("userDetails",response.getBody());
		if(response!=null) {
			mav.setViewName("dashboard");
		}
		return mav;
	}
	
	@RequestMapping("/MissingNumberPage")
	public ModelAndView MissingNumberPage() {
		ModelAndView mav=new ModelAndView();
		mav.addObject("requestPojo",new UserPojo());
		mav.setViewName("MissingNumberPage");
		return mav;
	}
	
	@RequestMapping("/checkMissingNumber")
	public ModelAndView checkMissingNumber(@ModelAttribute("requestPojo") UserPojo uPojo,HttpServletRequest req,HttpServletResponse res,HttpSession session) {
		ModelAndView mav = new ModelAndView();
		UserPojo userPojo = (UserPojo) session.getAttribute("userDetails");
		if(userPojo!=null) {
			RestTemplate restTemplate=new RestTemplate();
			UserPojo u = new UserPojo();
			u.setArr(uPojo.getArr());
			u.setArr2(uPojo.getArr2());
			HttpHeaders headers = new HttpHeaders();
		      headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
		      headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<UserPojo> request = new HttpEntity<>(u,headers);
			 
			ResponseEntity<UserPojo> response = restTemplate.exchange("http://localhost:8082/NSCIT-RestAPI/checkMissingNumber", HttpMethod.POST, request, UserPojo.class);
			System.out.println("response" +response);
			mav.addObject("missingNumber",response.getBody());
			mav.setViewName("MissingNumber");
		}else {
			mav.setViewName("index");
		}
		return mav;
	}
	
	@RequestMapping("/PalindromePage")
	public ModelAndView PalindromePage() {
		ModelAndView mav=new ModelAndView();
		mav.addObject("requestPojo",new UserPojo());
		mav.setViewName("PalindromePage");
		return mav;
	}
	
	@RequestMapping("/checkPalindrome")
	public ModelAndView checkPalindrome(HttpServletRequest req,HttpServletResponse res,HttpSession session) {
		ModelAndView mav = new ModelAndView();
		UserPojo userPojo = (UserPojo) session.getAttribute("userDetails");
		if(userPojo!=null) {
			RestTemplate restTemplate=new RestTemplate();
			UserPojo u = new UserPojo();
			u.setEmail(userPojo.getEmail());
			u.setPassword(passwordHashing.generateHash(userPojo.getPassword()));
			HttpHeaders headers = new HttpHeaders();
		      headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
		      headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<UserPojo> request = new HttpEntity<>(u,headers);
			 
			ResponseEntity<UserPojo> response = restTemplate.exchange("http://localhost:8082/NSCIT-RestAPI/checkPalindrome", HttpMethod.POST, request, UserPojo.class);
			System.out.println("response" +response);
			mav.addObject("palindrome",response.getBody());
			mav.setViewName("success");
		}else {
			mav.setViewName("index");
		}
		return mav;
	}
	
}
