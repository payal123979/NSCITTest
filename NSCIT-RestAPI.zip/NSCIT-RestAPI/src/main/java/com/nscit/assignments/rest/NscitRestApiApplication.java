package com.nscit.assignments.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NscitRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NscitRestApiApplication.class, args);
	}
	
	

}
