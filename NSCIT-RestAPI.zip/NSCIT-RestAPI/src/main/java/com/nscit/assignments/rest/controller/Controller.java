package com.nscit.assignments.rest.controller;

import java.util.Arrays;

import java.util.Collection;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nscit.assignments.rest.repository.UserRepository;
import com.nscit.assignments.test.entity.User;
import com.nscit.assignments.test.entity.UserPojo;

@RestController
@CrossOrigin(origins = "http://localhost:8081/",allowedHeaders="*")
public class Controller {

	@Autowired
	UserRepository userRepository;
	
	@RequestMapping(value="/saveUserData",method=RequestMethod.POST)
	public String saveUserData(@RequestBody UserPojo userPojo) {
		System.out.println("userojo" + userPojo.getName());
		User u = new User();
		u.setEmail(userPojo.getEmail());
		u.setName(userPojo.getName());
		u.setPassword(userPojo.getPassword());
		 User u1=userRepository.save(u);
		 if(u1!=null) {
			 return "successfully submitted";
		 }
		return "failed to submit";
		
	}
	
	
	@RequestMapping(value="/saveLoginData",method=RequestMethod.POST)
	public UserPojo saveLoginData(@RequestBody UserPojo userPojo) {
		System.out.println("userojo" + userPojo.getEmail());
		User u = userRepository.findByEmailAndPassword(userPojo.getEmail(),userPojo.getPassword());
		UserPojo upojo = new UserPojo();
		upojo.setEmail(u.getEmail());
		upojo.setName(u.getName());
		upojo.setPassword(u.getPassword());
		if(u!=null) {
			 return upojo;
		 }
		return null;
		
	}
	
	

	@RequestMapping(value="/checkMissingNumber",method=RequestMethod.POST)
	public Object checkMissingNumber(@RequestParam("arr1") Integer[] arr1,@RequestParam("arr2") Integer[] arr2) {
		System.out.println("arr1  :"+arr1 +" arr2 :"+arr2 );
		 List<Integer> list1 = Arrays.asList(arr1);
	        List<Integer> list2 = Arrays.asList(arr2);
	        Collection<Integer> result = CollectionUtils.disjunction(list2, list1);
	        System.out.println(result);
		return result;
		
	}
	
	
	@RequestMapping(value="/checkPalindrome",method=RequestMethod.POST)
	public Object checkPalindrome(@RequestParam("data") String s) {
		String reverse = new StringBuffer(s).reverse().toString();
		 
	    // check whether the string is palindrome or not
	    if (s.equals(reverse))
	    	return "success";
	 
	    else
	      return "failed";
		
		
	}
	    
}
