package com.nscit.assignments.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nscit.assignments.test.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

	User findByEmailAndPassword(String email, String password);


}
